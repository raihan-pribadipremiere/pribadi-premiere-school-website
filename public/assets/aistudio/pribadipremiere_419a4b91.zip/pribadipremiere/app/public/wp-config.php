<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '^yXmyPKhOuv=;2>xOsn>qynKK0a*,9TnKy9~3~5~Ku oc=Vl(W]j~Ec0omVBF#,<' );
define( 'SECURE_AUTH_KEY',   'EPeli$,JU}!~=4<|hTxr[J0K_]leE86{U4@UZ+>K.B6(&*@0Aa,%FZmhpH &na]Q' );
define( 'LOGGED_IN_KEY',     'rRc>p~~Q6qR{iN;)>9($f.x@atJ-.4)6YV`VOs=hhBX y2ScWn4R&C%yKae#h[G4' );
define( 'NONCE_KEY',         'Bb37P>mFrq2ghN0=}=#DNR4jvx~g8m.I`C1:`/Zu)wn8k?A.Z+@A:_uJQn4sb$~B' );
define( 'AUTH_SALT',         'wF={A_T#kKoK+Mecjcdi@(R,YT>U=Xfa&+iS`t%G`I7@F^mNA-L5Dc.{3Qu)#dNo' );
define( 'SECURE_AUTH_SALT',  '({OWjV<WZ$!#h<SzF%-/}tkN$[|d`:cY^EF{4&(40U,AID{{$J.aP0xdKSO5F/ ^' );
define( 'LOGGED_IN_SALT',    '|Rwt?YWEZ;K<Z}=nEzW*8f}V)Elu{`Qf?]rVgzgLHyN<=uKEw(#*0AL:oj+d3W_I' );
define( 'NONCE_SALT',        'pIjyI1OY%I3gccZNj 5%syZBoCoW@=+2BZDd6r0L-`AR>L0t4`!v/s7I(oo*bPe5' );
define( 'WP_CACHE_KEY_SALT', 'SVUVm+Fr[TCs9,rqJ-`qkwVv*y3Oq9&u`HgVL_+J.u(b1*BR8jh6-B~cGdz-%fb_' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
